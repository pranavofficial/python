def char_frequency(str1):
    dict = {}
    for n in str1:
        keys = dict.keys()
        if n in keys:
            dict[n] += 1
        else:
            dict[n] = 1
    return dict
letter = input("What sentence would you like to have the letters counted of? ")
print(char_frequency(letter))